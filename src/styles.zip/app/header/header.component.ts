import { Component, OnInit } from '@angular/core';
// import imagePath from '/Users/mac/krist/src/app/header/images/f.png';
//
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
export class HeaderComponent implements OnInit {
  // image = imagePath;
  constructor() {}

  ngOnInit(): void {}
}
