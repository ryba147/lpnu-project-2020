import { Component } from '@angular/core';
import {HeaderComponent} from './header/header.component'
import {FooterComponent} from './footer/footer.component'
import { FormGroup, FormBuilder, Validators} from '@angular/forms';
import { from } from 'rxjs';

@Component({
  selector: 'app-root',
  template: `<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"><app-header></app-header><router-outlet></router-outlet><app-footer></app-footer>`
})
export class AppComponent {
  title = 'frontend';
}
