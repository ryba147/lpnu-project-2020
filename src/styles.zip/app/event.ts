export class Event{
    event_name:string;
    event_description:string;
    //PATH TO THE IMAGE
    event_photo:string;
    event_date:Date;

}